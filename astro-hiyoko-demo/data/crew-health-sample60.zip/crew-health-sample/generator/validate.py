#!/usr/bin/env python3
"""Validate the 60-second fixture using only the standard library."""
import argparse
import hashlib
import json
import math
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
NAMES = ["mira", "kai", "lin", "noa", "sol"]
CODES = ["heart_rate", "spo2", "temperature", "blood_pressure_systolic",
         "blood_pressure_diastolic", "respiratory_rate", "work_of_breathing"]
UNITS = ["/min", "%", "Cel", "mm[Hg]", "mm[Hg]", "/min", "1"]
CONTEXTS = [{"activity": "rest"}, {"measurementSite": "finger"},
            {"measurementSite": "oral", "temperatureType": "oral"},
            {"posture": "seated"}, {"posture": "seated"},
            {"observationDuration": 60}, {}]
CENTERS = [(68, 98, 36.6, 116, 74, 16), (74, 97.5, 36.7, 120, 78, 16),
           (70, 98, 36.5, 118, 76, 16), (72, 98.5, 36.6, 114, 72, 16),
           (66, 97.5, 36.7, 122, 80, 16)]
RANGES = [2, 0.5, 0.1, 3, 2, 1]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def reject_constant(value):
    raise ValueError(f"Invalid JSON number: {value}")


def check_metric(metric, code, crew_index, sid):
    index = CODES.index(code)
    keys = {"code", "value", "unit", "method", "context", "quality"}
    if code in CODES[3:5]:
        keys.add("measurementGroupId")
    if code == "work_of_breathing":
        keys.add("qualityReason")
    require(set(metric) == keys, f"{sid}: fields for {code}")
    require(metric["unit"] == UNITS[index] and metric["context"] == CONTEXTS[index],
            f"{sid}: unit/context for {code}")
    require(metric["method"] == "mock_generated", f"{sid}: method")
    if code == "work_of_breathing":
        require(metric["value"] is None and metric["quality"] == "missing"
                and metric["qualityReason"] == "scale_not_configured", f"{sid}: scale placeholder")
        return
    value = metric["value"]
    require(type(value) in (int, float) and math.isfinite(value) and metric["quality"] == "good",
            f"{sid}: finite good number for {code}")
    require(abs(value - CENTERS[crew_index][index]) <= RANGES[index] + 1e-8,
            f"{sid}: reference range for {code}")
    if code in ("heart_rate", "respiratory_rate", *CODES[3:5]):
        require(type(value) is int, f"{sid}: integer for {code}")
    else:
        require(abs(value * 10 - round(value * 10)) < 1e-8, f"{sid}: decimal precision")
    if code == "respiratory_rate":
        require(type(metric["context"]["observationDuration"]) in (int, float), f"{sid}: duration type")
    if code in CODES[3:5]:
        require(metric["measurementGroupId"] == sid + ":bp", f"{sid}: blood-pressure group")


def validate(root):
    raw = (root / "live.jsonl").read_bytes()
    require(not raw.startswith(bytes([239, 187, 191])) and raw.endswith(b"\n") and b"\r" not in raw,
            "Expected UTF-8 without BOM, LF lines, and final newline")
    rows = [json.loads(s, parse_constant=reject_constant) for s in raw.decode("utf-8").splitlines()]
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    expected_manifest = {
        "datasetId": "crew-health-v1", "datasetVersion": "1.1.1-sample60",
        "dataSchemaVersion": "1.1", "telemetrySchemaVersion": "1.3", "seed": 20261114,
        "timeUnit": "ms", "liveDurationMs": 60000, "tickMs": 1000, "playbackRate": 1,
        "crew": [{"crewId": n, "deviceId": "mock-" + n, "assignmentId": "assignment-" + n} for n in NAMES],
        "files": [{"path": "live.jsonl", "sampleCount": 300, "metricCount": 1215}],
        "deliveryWindows": [], "backfillMaxPacketsPerSecond": 10,
    }
    require(manifest == expected_manifest, "Manifest scope/version/count mismatch")
    require(len(rows) == 300, "Expected 300 rows")
    counts: Counter[str] = Counter()
    sequences: dict[str, list[int]] = {name: [] for name in NAMES}
    for index, row in enumerate(rows):
        second, crew_index = divmod(index, 5)
        name = NAMES[crew_index]
        sid = f"{name}:L:{second:06d}"
        require(set(row) == {"sampleId", "crewId", "tMs", "metrics"}, f"{sid}: sample fields")
        require(type(row["tMs"]) is int and (row["sampleId"], row["crewId"], row["tMs"])
                == (sid, name, second * 1000), f"{sid}: identity/order/time")
        expected = CODES if second == 0 else CODES[:2] + CODES[5:]
        metrics = row["metrics"]
        require([m["code"] for m in metrics] == expected, f"{sid}: codes/order/cadence")
        for metric in metrics:
            check_metric(metric, metric["code"], crew_index, sid)
            counts[metric["code"]] += 1
        values = {m["code"]: m["value"] for m in metrics}
        sequences[name].append(values["respiratory_rate"])
        if second == 0:
            require(values[CODES[3]] > values[CODES[4]], f"{sid}: blood-pressure order")
            continue
        prior = {m["code"]: m["value"] for m in rows[index - 5]["metrics"]}
        for code, limit in [("heart_rate", 3), ("spo2", 0.3), ("respiratory_rate", 1)]:
            require(abs(values[code] - prior[code]) <= limit + 1e-8, f"{sid}: smoothness for {code}")
    require(sum(counts.values()) == 1215, "Expected 1215 metrics")
    require(all(len(set(s)) >= 2 for s in sequences.values()), "Respiratory variation missing")
    require(len({tuple(s) for s in sequences.values()}) == 5, "Duplicated respiratory sequences")
    return {"datasetVersion": manifest["datasetVersion"], "telemetrySchemaVersion": "1.3",
            "sampleCount": len(rows), "metricCount": sum(counts.values()), "perMetric": dict(counts),
            "localStructuralChecks": "passed", "failures": [],
            "telemetrySchemaModelCheck": "See backend-validation.json; rerun after data changes",
            "fullDatasetD01ToD09": "not_run; only 60 live seconds",
            "hardwareAnd3DFullAcceptance": "not_run; history and fault scenarios not included"}


def verify_hashes(root):
    for line in (root / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
        expected, name = line.split("  ", 1)
        target = (root / name).resolve()
        require(root.resolve() in target.parents, "Checksum path escapes package")
        require(hashlib.sha256(target.read_bytes()).hexdigest() == expected, f"SHA-256 mismatch: {name}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify-hashes", action="store_true", help="Read-only checksum and content validation")
    args = parser.parse_args()
    if args.verify_hashes:
        verify_hashes(ROOT)
        print(json.dumps(validate(ROOT)))
        return
    report = validate(ROOT)
    (ROOT / "validation-report.json").write_bytes((json.dumps(report, indent=2) + "\n").encode("utf-8"))
    files = sorted(p for p in ROOT.rglob("*") if p.is_file() and p.name != "SHA256SUMS.txt"
                   and "__pycache__" not in p.parts)
    hashes = "".join(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(ROOT).as_posix()}\n" for p in files)
    (ROOT / "SHA256SUMS.txt").write_bytes(hashes.encode("utf-8"))
    print(json.dumps(report))


if __name__ == "__main__":
    main()
