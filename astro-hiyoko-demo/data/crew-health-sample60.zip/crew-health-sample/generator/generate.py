#!/usr/bin/env python3
"""Generate the five-crew, first-60-second format integration sample."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SEED = 20261114
CREW = [
    ("mira", 68, 980, 366, 116, 74),
    ("kai", 74, 975, 367, 120, 78),
    ("lin", 70, 980, 365, 118, 76),
    ("noa", 72, 985, 366, 114, 72),
    ("sol", 66, 975, 367, 122, 80),
]


def phase(name, metric):
    raw = f"{SEED}:{name}:{metric}".encode()
    return int.from_bytes(hashlib.sha256(raw).digest()[:4], "big") % 60


def wave(t, name, metric, amplitude, period):
    # A triangular wave changes smoothly and has exact, platform-independent values.
    position = (t + phase(name, metric)) % period
    half = period // 2
    return round(-amplitude + 2 * amplitude * (position if position <= half else period - position) / half)


def metric(code, value, unit, context, group=None):
    item = {"code": code, "value": value, "unit": unit,
            "method": "mock_generated", "context": context}
    if group is not None:
        item["measurementGroupId"] = group
    item["quality"] = "good"
    return item


def sample(t, profile):
    name, hr, spo2, temp, sys, dia = profile
    sid = f"{name}:L:{t:06d}"
    values = [
        metric("heart_rate", hr + wave(t, name, "hr", 2, 40), "/min", {"activity": "rest"}),
        metric("spo2", (spo2 + wave(t, name, "spo2", 5, 50)) / 10, "%", {"measurementSite": "finger"}),
    ]
    if t == 0:
        group = sid + ":bp"
        values.extend([
            metric("temperature", (temp + wave(t, name, "temp", 1, 20)) / 10,
                   "Cel", {"measurementSite": "oral", "temperatureType": "oral"}),
            metric("blood_pressure_systolic", sys + wave(t, name, "sys", 3, 30),
                   "mm[Hg]", {"posture": "seated"}, group),
            metric("blood_pressure_diastolic", dia + wave(t, name, "dia", 2, 20),
                   "mm[Hg]", {"posture": "seated"}, group),
        ])
    values.extend([
        metric("respiratory_rate", 16 + wave(t, name, "respiratory_rate", 1, 30),
               "/min", {"observationDuration": 60}),
        {"code": "work_of_breathing", "value": None, "unit": "1",
         "method": "mock_generated", "context": {}, "quality": "missing",
         "qualityReason": "scale_not_configured"},
    ])
    return {"sampleId": sid, "crewId": name, "tMs": t * 1000, "metrics": values}


def main():
    rows = [sample(t, profile) for t in range(60) for profile in CREW]
    live = "".join(json.dumps(row, ensure_ascii=False, separators=(",", ":"), allow_nan=False) + "\n"
                   for row in rows)
    (ROOT / "live.jsonl").write_bytes(live.encode("utf-8"))
    manifest = {
        "datasetId": "crew-health-v1", "datasetVersion": "1.1.1-sample60",
        "dataSchemaVersion": "1.1", "telemetrySchemaVersion": "1.3", "seed": SEED,
        "timeUnit": "ms", "liveDurationMs": 60000, "tickMs": 1000, "playbackRate": 1,
        "crew": [{"crewId": name, "deviceId": "mock-" + name,
                  "assignmentId": "assignment-" + name} for name, *_ in CREW],
        "files": [{"path": "live.jsonl", "sampleCount": 300, "metricCount": 1215}],
        "deliveryWindows": [], "backfillMaxPacketsPerSecond": 10,
    }
    (ROOT / "manifest.json").write_bytes((json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))


if __name__ == "__main__":
    main()
