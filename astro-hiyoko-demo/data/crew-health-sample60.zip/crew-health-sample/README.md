# 五人健康資料 60 秒格式聯調樣本
# Five Person Health Data 60 Second Integration Sample

資料版本 1.1.1-sample60；共用格式 1.1；醫療 API schema 1.3；配套中英規格版本 1.2。
Dataset version 1.1.1-sample60; data schema 1.1; medical API schema 1.3; companion specification version 1.2.

五人各 60 行，一秒一行，共 300 行、1,215 個 metric。第 0 秒包含全部七項；其他秒含心率、血氧、呼吸頻率與呼吸費力。全部為合成訓練資料；本包只有前 60 秒穩定情境，不含七天歷史或完整十分鐘驗收情境。
Each person has 60 one-second rows: 300 rows and 1,215 metric entries total. Second zero includes all seven codes; other seconds contain heart rate, SpO2, respiratory rate, and work of breathing. All data is synthetic. This package contains only the first 60 stable seconds, not seven-day history or full ten-minute acceptance scenarios.

呼吸頻率為整數 15～17 /min，每秒更新，observationDuration=60 是重疊觀察窗秒數。每人使用不同的可重現序列。呼吸費力固定 null/missing/scale_not_configured，不可填 0 或虛構分數。心率用 /min，血壓用 mm[Hg]。
Respiratory rate uses integers from 15 to 17 /min, updated every second; observationDuration=60 represents overlapping observation windows in seconds. Each person has a distinct reproducible sequence. Work of breathing is always null/missing/scale_not_configured, never zero or an invented score. Heart rate uses /min and blood pressure mm[Hg].

## 生成與驗證 Generate and validate

Python 3.9+，僅標準函式庫；固定種子 20261114，生成器版本 1.1.1。下列命令在解壓縮後的 crew-health-sample 資料夾執行。
Python 3.9+ with only the standard library; fixed seed 20261114, generator release 1.1.1. Run these commands in the extracted crew-health-sample directory.

```sh
python generator/validate.py --verify-hashes
python generator/generate.py
python generator/validate.py
python generator/validate.py --verify-hashes
```

第一個命令唯讀驗證交付檔案雜湊及內容。generate 重建 live.jsonl 與 manifest.json；validate 驗證後更新本地報告及 SHA256SUMS.txt。重跑生成應得到完全相同的資料檔。修改規則後須升版並重新驗證；不可沿用 backend-validation.json 的舊通過結果。
The first command verifies delivered hashes and content without writing. generate rebuilds live.jsonl and manifest.json; validate updates the local report and SHA256SUMS.txt after validation. Regeneration must reproduce identical data files. Change the version and repeat validation after editing rules; existing backend-validation.json results do not certify modified data.

本地驗證涵蓋版本、筆數、身分、時序、欄位、單位、context、型別、品質、基準範圍、平滑變化、血壓配對及呼吸序列差異。backend-validation.json 記錄交付時實際後端模型／API 檢查，綁定資料與程式雜湊。完整 D/E/X 驗收不因小樣本通過而視為完成。
Local checks cover versions, counts, identity, timing, fields, units, contexts, types, quality, reference ranges, smoothness, blood-pressure pairs, and distinct respiratory sequences. backend-validation.json records delivery-time model/API checks tied to data and source hashes. A sample pass does not establish full D/E/X acceptance.

## 傳送與後續交付 Transmission and next delivery

排序為 tMs、再按 mira、kai、lin、noa、sol。本包沒有歷史，seq 每人 1～60；傳送端建立 playbackId、T0 及 HTTP 封包，五人同秒共用 observedAt=T0+tMs。兩條路徑讀同一檔案，不重新抽樣。完整資料另依規格預載歷史並配置序號，不可直接接續小樣本序號。
Rows are ordered by tMs, then mira, kai, lin, noa, sol. With no history, seq is 1–60 per person. The sender creates playbackId, T0, and HTTP packets; all five people at the same second share observedAt=T0+tMs. Both paths read identical files without resampling. Full datasets preload history and use the specified sequence allocation; do not continue directly from sample sequences.

本包不含 Token、絕對時間或播放器。裝置 Token 及部署網址由軟體組另行提供。TMP117 已確認為模擬型號，本樣本省略選填 sensor。韌體規劃的呼吸費力 0～10 模擬規則尚未定案，score 所需規則識別／版本不能捏造；本版維持呼吸費力缺值。睡眠與疲勞排除於 telemetry。
No tokens, absolute timestamps, or player are included. The software team supplies credentials and deployment URL separately. TMP117 is confirmed as simulated model metadata; this sample omits the optional sensor field. Firmware plans 0–10 work-of-breathing simulation values, but rules and identifiers remain pending. Do not invent score identifiers; this release retains missing work-of-breathing values. Sleep and fatigue are excluded from telemetry.
